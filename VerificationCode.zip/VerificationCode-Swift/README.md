**Asun - Swift - Verification - code**
这是一个Swift版本的验证码Demo
![image](https://github.com/BecomerichAsun/VerificationCode-Swift/blob/master/VerificationCode/Image/code.gif)

**使用方法**
![image](https://github.com/BecomerichAsun/VerificationCode-Swift/blob/master/VerificationCode/Image/use.png)
**如果你想线的宽度或者间隙的宽度 需要在CodeView中更改枚举**

**以下验证码的基本属性,调用其中Mutaing方法能更改基本属性**
![image](https://github.com/BecomerichAsun/VerificationCode-Swift/blob/master/VerificationCode/Image/Basic.png)

如果喜欢的话 请给我一个🌟 

